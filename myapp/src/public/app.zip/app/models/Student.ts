export class Student {
  studentName: string;
  rollNo: string;
  classDiv: string;
  gender: string;
  status: string;
  image: string;
}
