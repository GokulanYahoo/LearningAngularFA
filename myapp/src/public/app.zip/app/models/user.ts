export class User {
    userName: String;
    password: String;
    constructor() { }
}
