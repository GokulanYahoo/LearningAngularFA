'use strict';

export let loginSession: any;